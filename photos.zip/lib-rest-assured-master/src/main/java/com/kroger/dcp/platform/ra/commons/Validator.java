package com.kroger.dcp.platform.ra.commons;

import org.json.JSONException;

import java.io.IOException;

public class Validator {
  public static void validate(Validatable v, OutputWriter o) throws Exception {
    String result = "Passed";
    try {
      v.validate();
    } catch (AssertionError error) {
      result = "Failed";
      throw new AssertionError(error);
    } catch (JSONException e) {
      e.printStackTrace();
    } finally {
      o.write(result);
    }
  }

  public interface OutputWriter {
    void write(String status) throws IOException;
  }

  public interface Validatable {
    void validate() throws Exception;
  }
}
