package com.kroger.dcp.platform.ra.utils;

import com.kroger.dcp.platform.ra.commons.ResultBuilder;
import io.restassured.response.ValidatableResponse;

import java.util.HashMap;

import static com.kroger.dcp.platform.ra.commons.FileHandler.readJsonTemplate;
import static com.kroger.dcp.platform.ra.commons.Logger.log;
import static com.kroger.dcp.platform.ra.commons.RestService.executePostRequest;
import static java.lang.String.format;

public class TestDataHandler {
  private String cpsCustomerProfileBaseURL;

  public TestDataHandler(String cpsCustomerProfileBaseURL) {
    this.cpsCustomerProfileBaseURL = cpsCustomerProfileBaseURL;
  }

  public Boolean createNewUser(String emailAddress, String bannerName,
                               String lastName, String divisionNumber,
                               String preferredStoreNumber, ResultBuilder resultBuilder) throws Exception {
    HashMap<String, String> requestParameters = new HashMap<>();
    String profileCreateURL = format("%s/create", cpsCustomerProfileBaseURL);
    requestParameters.put("bannerName", bannerName);
    requestParameters.put("emailAddress", emailAddress);
    requestParameters.put("lastName", lastName);
    requestParameters.put("divisionNumber", divisionNumber);
    requestParameters.put("preferredStoreNumber", preferredStoreNumber);
    String requestJson = readJsonTemplate("templates/CreateUserDefault.json", requestParameters);
    log(format("RequestJSON for Create user=\n%s", requestJson));
    resultBuilder.withRequestJson(requestJson)
        .withRequestUrl(profileCreateURL);
    log(format("%s", resultBuilder.getRequestJson()));
    log(format("%s", resultBuilder.getRequestUrl()));
    ValidatableResponse response = executePostRequest(resultBuilder);
    log("status = "+response.extract().statusCode());
    log("response = "+response.extract().body().asString());
    if (response.extract().statusCode() == 200) {
      log(format("User created for %s", emailAddress));
      return true;
    }
    log(format("User creation failed with email id: %s", emailAddress));
    return false;
  }

  public Boolean deleteUser(String emailAddress, ResultBuilder resultBuilder) throws Exception {
    HashMap<String, String> requestParameters = new HashMap<>();
    String deleteProfileURL = format("%s/delete", cpsCustomerProfileBaseURL);
    String requestJsonFilePath = "templates/DeleteUser.json";
    requestParameters.put("emailAddress", emailAddress);
    String requestJson = readJsonTemplate(requestJsonFilePath, requestParameters);
    resultBuilder.withRequestUrl(deleteProfileURL)
        .withRequestJson(requestJson);
    log(format("RequestJSON for delete user=\n%s", requestJson));
    ValidatableResponse response = executePostRequest(resultBuilder);
    log("status = "+response.extract().statusCode());
    log("Create virtual card response: "+response.extract().body().asString());
    if (response.extract().statusCode() == 200) {
      log(emailAddress + "deleted");
      return true;
    } else {
      log(format("delete user failed for email id: %s", emailAddress));
      return false;
    }
  }

  public Boolean createVirtualCard(String emailAddress, String altID,
                                   String lastName, String bannerName, String divisionNumber,
                                   ResultBuilder resultBuilder) throws Exception {
    HashMap<String, String> requestParameters = new HashMap<>();
    String virtualCardCreateURL = format("%s/virtual-card/put", cpsCustomerProfileBaseURL);
    String requestJsonFilePath = "templates/VirtualCardDefault.json";
    requestParameters.put("altID", altID);
    requestParameters.put("bannerName", bannerName);
    requestParameters.put("emailAddress", emailAddress);
    requestParameters.put("lastName", lastName);
    requestParameters.put("divisionNumber",divisionNumber);
    String requestJson = readJsonTemplate(requestJsonFilePath, requestParameters);
    log(format("RequestJSON for virtual card put=\n%s", requestJson));
    resultBuilder.withRequestJson(requestJson)
        .withRequestUrl(virtualCardCreateURL);
    ValidatableResponse response = executePostRequest(resultBuilder);
    log(format("virtual card JSON  %s", requestJson));

    if (response.extract().statusCode() == 200) {
      log(format("virtual card created for %s", emailAddress));
      return true;
    }
    log("virtual cad creation failed");
    return false;
  }
}