package com.kroger.dcp.platform.ra.commons;

import static org.apache.commons.lang3.StringEscapeUtils.escapeCsv;

public class ResultBuilder {
  private String scenarioName = "";
  private String result = "";
  private String requestUrl = "";
  private String requestJson = "";
  private int expectedStatus = 0;
  private int actualStatus = 0;
  private String expectedResponseJson = "{}";
  private String actualResponse = "";
  private String requestType = "";
  private String requestParams = null;
  private String authHeader = null;

  public ResultBuilder withScenarioName(String scenarioName) {
    this.scenarioName = scenarioName;
    return this;
  }

  public ResultBuilder withRequestType(String requestType) {
    this.requestType = requestType;
    return this;
  }

  public ResultBuilder withResult(String result) {
    this.result = result;
    return this;
  }

  public ResultBuilder withAuthHeader(String authHeader){
    this.authHeader = authHeader;
    return this;
  }

  public ResultBuilder withRequestParams(String requestParams) {
    this.requestParams = requestParams;
    return this;
  }

  public ResultBuilder withRequestUrl(String requestUrl) {
    this.requestUrl = requestUrl;
    return this;
  }

  public ResultBuilder withRequestJson(String request) {
    this.requestJson = request;
    return this;
  }

  public ResultBuilder withExpectedHttpStatus(int expectedStatus) {
    this.expectedStatus = expectedStatus;
    return this;
  }

  public ResultBuilder withActualStatus(int actualStatus) {
    this.actualStatus = actualStatus;
    return this;
  }

  public ResultBuilder withExpectedResponseJson(String expectedResponseJson) {
    this.expectedResponseJson = expectedResponseJson;
    return this;
  }

  public ResultBuilder withActualResponse(String actualResponse) {
    this.actualResponse = actualResponse;
    return this;
  }

  public String getScenarioName() {
    return scenarioName;
  }

  public String getRequestJson() {
    return requestJson;
  }

  public int getExpectedHttpStatus() {
    return expectedStatus;
  }

  public String getExpectedResponseJson() {
    return expectedResponseJson;
  }

  public String getRequestUrl() {
    return requestUrl;
  }

  public String build() {
    if (expectedStatus == 0) {
      throw new IllegalArgumentException("expected status is not assigned with any value");
    }
    if (actualStatus == 0) {
      throw new IllegalArgumentException("expected status is not assigned with any value");
    }
    return escapeCsv(this.scenarioName) + "," + result +
        "," + requestType + "," + requestUrl +
        "," + requestParams + "," + escapeCsv(requestJson) +
        "," + expectedStatus + "," + actualStatus +
        "," + escapeCsv(expectedResponseJson) + "," + escapeCsv(actualResponse);
  }

  public String getAuthHeader() {
    return authHeader;
  }
}
