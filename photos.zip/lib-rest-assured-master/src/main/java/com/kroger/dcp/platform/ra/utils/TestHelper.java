package com.kroger.dcp.platform.ra.utils;

import com.kroger.dcp.platform.ra.commons.ResultBuilder;
import io.restassured.response.ValidatableResponse;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.kroger.dcp.platform.ra.commons.FileHandler.write;
import static com.kroger.dcp.platform.ra.commons.Logger.log;
import static com.kroger.dcp.platform.ra.commons.Validator.validate;
import static java.lang.String.format;
import static java.util.Objects.nonNull;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

public class TestHelper {

  protected ResultBuilder resultBuilder = new ResultBuilder();
  private String outputFile;

  public TestHelper(String outputFilePath) {
    outputFile = createOutputFile(outputFilePath);
  }

  public void validateResponse(ValidatableResponse response, ResultBuilder resultBuilder) throws Exception {
    log("Validating the Response");
    validate(() -> {
      response.statusCode(resultBuilder.getExpectedHttpStatus());
      assertEquals(resultBuilder.getExpectedResponseJson(), response.extract().body().asString(), JSONCompareMode.LENIENT);
    }, result -> {
      log(format("Test%s", result));
      resultBuilder.withResult(result);
      write(resultBuilder.build(), outputFile);
    });
  }

  public void validateResponseSize(ValidatableResponse response, int expectedSize, ResultBuilder resultBuilder) throws Exception {
    log("Validating the Response");
    validate(() -> {
      response.statusCode(resultBuilder.getExpectedHttpStatus());
      Assert.assertEquals(expectedSize, response.extract().jsonPath().getList("$").size());
    }, result -> {
      log(format("Test%s", result));
      resultBuilder.withResult(result);
      write(resultBuilder.build(), outputFile);
    });
  }

  public void validateResponseSizeGreaterThanOrEqualto(ValidatableResponse response, int expectedSize, ResultBuilder resultBuilder) throws Exception {
    log("Validating the Response");
    validate(() -> {
      response.statusCode(resultBuilder.getExpectedHttpStatus());
      Assert.assertTrue(response.extract().jsonPath().getList("$").size()>=expectedSize);
    }, result -> {
      log(format("Test%s", result));
      resultBuilder.withResult(result);
      write(resultBuilder.build(), outputFile);
    });
  }

  private String createOutputFile(String outputFilePath) {
    String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()).replace('.', '_');
    String outputFileName = format("%s/%sResults_%s.csv", outputFilePath, getTestClassName(), timeStamp);
    write("scenarioName,result,requestType,requestURL,requestParams,requestJson,expectedResponseStatus,actualResponseStatus,expectedEnrollmentResponseJson,actualResponseJson", outputFileName, false);
    return outputFileName;
  }

  private String getTestClassName() {
    StackTraceElement[] stElements = Thread.currentThread().getStackTrace();
    if (nonNull(stElements))
      return stElements[4].getFileName().split("\\.")[0];
    return "";
  }
}
