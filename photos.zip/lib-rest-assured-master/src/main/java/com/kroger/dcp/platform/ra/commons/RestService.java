package com.kroger.dcp.platform.ra.commons;

import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.kroger.dcp.platform.ra.commons.FileHandler.readJSON;
import static io.restassured.RestAssured.given;

public class RestService {

  public static String constructJsonFromFile(HashMap<String, String> jsonValues, String jsonFilePath) throws Exception {
    JSONObject inputJsonTemplate = readJSON(jsonFilePath);
    return constructJson(jsonValues, inputJsonTemplate.toJSONString());
  }

  public static String constructJson(HashMap<String, String> jsonValues, String json) {
    for (Map.Entry<String, String> entry : jsonValues.entrySet()) {
      String key = String.format("$%s$", entry.getKey());
      json = json.replace(key, entry.getValue());
    }
    Logger.log("JSON is constructed");
    return json;
  }

  public static ValidatableResponse executePostRequest(ResultBuilder resultBuilder) {
    Logger.log("Executing POST request");
    RequestSpecification request = given().when();
    addHeader(resultBuilder, request);
    ValidatableResponse response = request.contentType("application/json").
        body(resultBuilder.getRequestJson()).
        post(resultBuilder.getRequestUrl()).
        then();
    resultBuilder.withRequestType("POST")
        .withActualStatus(response.extract().statusCode())
        .withActualResponse(response.extract().body().asString());
    return response;
  }

  private static void addHeader(ResultBuilder resultBuilder,
                                                RequestSpecification request) {
    String correlationId = UUID.randomUUID().toString();
    request.header("X-Correlation-Id", correlationId);
    if (resultBuilder.getAuthHeader() == null) return;
    request.header("Authorization",resultBuilder.getAuthHeader());
  }

  public static ValidatableResponse executeGetRequest(ResultBuilder resultBuilder, String correlationId) {
    ValidatableResponse response = given().
        when().
        header("X-Correlation-Id", correlationId).
        contentType("application/json").
        get(resultBuilder.getRequestUrl()).
        then();
    resultBuilder.withRequestType("GET")
        .withActualStatus(response.extract().statusCode())
        .withActualResponse(response.extract().body().asString());
    return response;
  }

  public static ValidatableResponse executeGetRequestWithParams(String correlationId, HashMap<String, String> params, ResultBuilder resultBuilder) {

    RequestSpecification requestSpecification = given().
        when().
        header("X-Correlation-Id", correlationId).
        contentType("application/json");

    for (Map.Entry<String, String> entry : params.entrySet()) {
      requestSpecification = requestSpecification.param(entry.getKey(), entry.getValue());
    }

    ValidatableResponse response = requestSpecification.get(resultBuilder.getRequestUrl()).then();
    resultBuilder.withRequestType("GET")
        .withActualStatus(response.extract().statusCode())
        .withActualResponse(response.extract().body().asString());
    return response;
  }
}
