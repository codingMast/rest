package com.kroger.dcp.platform.ra.commons;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import static com.kroger.dcp.platform.ra.commons.Logger.log;
import static com.kroger.dcp.platform.ra.commons.RestService.constructJson;
import static java.lang.String.format;

public class FileHandler {
  public static Collection readCSV(Reader csvReader) throws IOException {
    log("Test Started");
    ArrayList<String[]> list = new ArrayList<>();
    Iterable<CSVRecord> records = CSVFormat.RFC4180.parse(csvReader);
    log("Reading the csv file\n");
    for (CSVRecord csvRecord : records) {
      ArrayList<String> currentRecord = new ArrayList<>();
      for (int currentItem = 0; currentItem < csvRecord.size(); currentItem++) {
        currentRecord.add(csvRecord.get(currentItem));
      }
      String[] eachRecord = new String[csvRecord.size()];
      eachRecord = currentRecord.toArray(eachRecord);
      list.add(eachRecord);
    }
    list.remove(0);
    return list;
  }

  public static void write(String output, String path, Boolean appendFlag) {
    try {
      PrintWriter writer = new PrintWriter(new FileOutputStream(new File(path), appendFlag));
      writer.append(output);
      writer.append(System.lineSeparator());
      writer.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
  }

  static JSONObject readJSON(String filePath) throws Exception {
    log(format("Reading Json from %s", filePath));
    JSONParser parser = new JSONParser();
    return (JSONObject) parser.parse(new FileReader(filePath));
  }

  public static void write(String output, String path) {
    log(format("Writing to the output file %s", path));
    write(output, path, true);
  }

  public static String readJsonTemplate(String jsonFilePath, HashMap<String, String> requestParameters) throws Exception {
    return constructJson(requestParameters, readJSONFromLocalResource(jsonFilePath).toString());
  }

  private static JSONObject readJSONFromLocalResource(String path) throws Exception {
    log(format("Reading Json from %s", path));
    ClassLoader classLoader = FileHandler.class.getClassLoader();
    InputStream resourceAsStream = classLoader.getResourceAsStream(path);
    StringBuilder stringBuilder = new StringBuilder();

    BufferedReader reader = new BufferedReader(new InputStreamReader(resourceAsStream));

    String line;
    while ((line = reader.readLine()) != null) {
      stringBuilder.append(line);
    }

    return (JSONObject) new JSONParser().parse(stringBuilder.toString());
  }
}
