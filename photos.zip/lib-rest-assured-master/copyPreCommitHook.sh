#!/bin/sh
rm -rf .git/hooks; mkdir -p .git/hooks; cp git-hooks/** .git/hooks/