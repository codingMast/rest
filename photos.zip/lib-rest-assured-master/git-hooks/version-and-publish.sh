#!/usr/bin/env bash

CONFLICT_COUNT=0
REMOTE=origin
BRANCH=$CI_COMMIT_REF_NAME

dealWithGitConflict() {
    if [ $CONFLICT_COUNT -lt 3 ]; then
        ((CONFLICT_COUNT++))
        >&2 echo "****** RETRY $CONFLICT_COUNT ******"
        git reset --hard $VERSION~1
        git tag -d $(git tag)
        git pull -r $REMOTE $BRANCH
        git fetch --tags
    else
        >&2 echo "Git Conflict Happened Too Many Times"
        exit 1
    fi
}

findNextVersionNumber() {
    # Grab latest version tag
    LATEST_VERSION_TAG=$(git tag -l --sort=v:refname | tail -n1)
    echo "Latest Version Tag: $LATEST_VERSION_TAG"

    LAST_COMMIT=$(git log --pretty=oneline --abbrev-commit -n1)
    echo "Last commit: $LAST_COMMIT"

    BREAKING_COMMIT=$(echo $LAST_COMMIT | grep -c "#breaking" || true)
    FEATURE_COMMIT=$(echo $LAST_COMMIT | grep -c "#feature" || true)
    FIX_COMMIT=$(echo $LAST_COMMIT | grep -c "#fix" || true)

    HAS_BREAKING_COMMITS=$(if [ $BREAKING_COMMIT != "0" ]; then echo "Yes"; else echo "No"; fi)
    HAS_FEATURE_COMMITS=$(if [ $FEATURE_COMMIT != "0" ]; then echo "Yes"; else echo "No"; fi)
    HAS_FIX_COMMITS=$(if [ $FIX_COMMIT != "0" ]; then echo "Yes"; else echo "No"; fi)

    echo "Has Breaking Commit: $HAS_BREAKING_COMMITS"
    echo "Has Feature Commit: $HAS_FEATURE_COMMITS"
    echo "Has Fix Commit: $HAS_FIX_COMMITS"


    MAJOR="$(echo $LATEST_VERSION_TAG | cut -d'.' -f1)"
    MINOR="$(echo $LATEST_VERSION_TAG | cut -d'.' -f2)"
    PATCH="$(echo $LATEST_VERSION_TAG | cut -d'.' -f3)"

    VERSION=""
    if [ $HAS_BREAKING_COMMITS = "Yes" ]; then
      VERSION="$(echo "$(($MAJOR + 1))")".0.0
    elif [ $HAS_FEATURE_COMMITS = "Yes" ]; then
      VERSION=$MAJOR."$(echo "$(($MINOR + 1))")".0
    elif [ $HAS_FIX_COMMITS = "Yes" ]; then
      VERSION=$MAJOR.$MINOR."$(echo "$(($PATCH + 1))")"
    else
        echo "No Hash! No version commit will be created."
    fi
}

versionAndPublish() {
    findNextVersionNumber
    if [ ! -z $VERSION ]; then
        echo "Will attempt to create version tag for version $VERSION"

        # Add SSH Key
        echo "Setting up SSH"
        which ssh-agent || ( apk update && apk upgrade && apk add --no-cache openssh-client -y )
        eval $(ssh-agent -s)
        ssh-add <(echo "$GITLAB_CI_GIT_SSH_PRIVATE_KEY")
        mkdir -p ~/.ssh
        [[ -f /.dockerenv ]] && echo -e "Host *\n\tStrictHostKeyChecking no\n\n" >> ~/.ssh/config

        # Modify Git to push via the git ssh url
        echo "Setting git config"
        git config remote.origin.pushurl $SSH_REPO_NAME
        git config user.email $EMAIL
        git config user.name $TEAM_NAME

        rm -rf .git/hooks
        echo "Removed git hooks"

        echo $BRANCH
        if [ "$BRANCH" = "master" ]; then
          echo "Creating version tag"
          git tag -a $VERSION -m "$VERSION"
        fi

        echo "Pushing the tag"
        git push -u $REMOTE HEAD:$BRANCH --follow-tags || (dealWithGitConflict && versionAndPublish)

        echo "version=$VERSION-rc" > version.properties

        ./gradlew artifactoryPublish
    fi
}

$@ >&2 versionAndPublish
