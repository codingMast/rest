#!/usr/bin/env bash

CURRENT_TAG=$(git describe)
  echo "Current Tag: $CURRENT_TAG"

VERSION="$CURRENT_TAG"-RELEASE
echo "$VERSION"

echo "version=$VERSION" > version.properties

./gradlew artifactoryPublish